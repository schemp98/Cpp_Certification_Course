#ifndef CHECK_H
#define CHECK_H

class Check {};

#endif