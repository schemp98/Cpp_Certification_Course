/*===========================================================================
 * Homework #1 - CSE40478
 *
 * File:    main.cpp
 * Author:  Ray Mitchell
 * Date:    4/16/2011
 *
 * Program Output:
 *    Test1 PASSED
 *    Test2 PASSED
 *    Test3 PASSED
 *===========================================================================*/
#include "UnitTests.h"

int main()
{
   RayMitchell::Homework1::UnitTests::TestAll();
}