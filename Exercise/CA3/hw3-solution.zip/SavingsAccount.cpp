/******************************************************************************
 * Homework #3 - CSE40477
 *
 * File:    SavingsAccount.cpp
 * Author:  Ray Mitchell
 *****************************************************************************/
#include <iostream>
using std::cerr;

#include "SavingsAccount.h"

const int MONTHS_IN_YEAR = 12;

// Static data members must be defined in a translation unit (initialized to
// 0 automatically)
double RayMitchell::SavingsAccount::annualInterestRate;

RayMitchell::SavingsAccount::SavingsAccount(double initialBalance)
{
    if (initialBalance < 0) {
        cerr << "Illegal initial balance " << initialBalance
            << "; must be greater than zero.  Setting to $0.00\n";
        savingsBalance = 0;
    }
    else {
        savingsBalance = initialBalance;
    }
}

double
    RayMitchell::SavingsAccount::getSavingsBalance() const
{
    return savingsBalance;
}

void
    RayMitchell::SavingsAccount::applyMonthlyInterest()
{
    savingsBalance += savingsBalance
        * (SavingsAccount::annualInterestRate) / MONTHS_IN_YEAR;
}

void
    RayMitchell::SavingsAccount::setAnnualInterestRate(double newInterestRate)
{
    if (newInterestRate < 0) {
        cerr << "Illegal interest rate " << newInterestRate
            << "; must be greater than zero.  Setting to 0%\n";
        SavingsAccount::annualInterestRate = 0;
    }
    else {
        SavingsAccount::annualInterestRate = newInterestRate;
    }
}
