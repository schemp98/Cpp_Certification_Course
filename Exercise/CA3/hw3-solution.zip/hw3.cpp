/******************************************************************************
 * Homework #3 - CSE40477
 *
 * File:    hw3.cpp
 * Author:  Ray Mitchell
 *
 * Program Output:
    Setting interest rate to 0.03
    Savings account #1 initial balance:  2000
    Savings account #2 initial balance:  3000
    Applying interest rate to accounts for first month
    Savings account #1 balance:  2005
    Savings account #2 balance:  3007.5
    Setting interest rate to 0.04
    Applying interest rate to accounts for second month
    Savings account #1 balance:  2011.68
    Savings account #2 balance:  3017.53
    Testing illegal interest rates and balances
    Illegal initial balance -1; must be greater than zero.  Setting to $0.00
    Illegal interest rate -0.01; must be greater than zero.  Setting to 0%
 *****************************************************************************/
#include <iostream>
using std::cout;

#include "SavingsAccount.h"
using RayMitchell::SavingsAccount;

const double MONTH_1_INTEREST_RATE = 0.03;
const double MONTH_2_INTEREST_RATE = 0.04;
const double ILLEGAL_INTEREST_RATE = -0.01;
const double SAVINGS_ACCOUNT_1_INITIAL_BALANCE = 2000.00;
const double SAVINGS_ACCOUNT_2_INITIAL_BALANCE = 3000.00;
const double ILLEGAL_INITIAL_BALANCE = -1.00;

int main()
{
    // Set interest rate for first month
    cout << "Setting interest rate to " << MONTH_1_INTEREST_RATE << "\n";
    SavingsAccount::setAnnualInterestRate(MONTH_1_INTEREST_RATE);

    // Initialize savings accounts
    SavingsAccount saver1(SAVINGS_ACCOUNT_1_INITIAL_BALANCE);
    SavingsAccount saver2(SAVINGS_ACCOUNT_2_INITIAL_BALANCE);
    cout << "Savings account #1 initial balance:  "
        << saver1.getSavingsBalance() << "\n";
    cout << "Savings account #2 initial balance:  "
        << saver2.getSavingsBalance() << "\n";

    // Apply interest to savings accounts for first month
    cout << "Applying interest rate to accounts for first month\n";
    saver1.applyMonthlyInterest();
    saver2.applyMonthlyInterest();
    cout << "Savings account #1 balance:  "
        << saver1.getSavingsBalance() << "\n";
    cout << "Savings account #2 balance:  "
        << saver2.getSavingsBalance() << "\n";

    // Set interest rate for second month
    cout << "Setting interest rate to " << MONTH_2_INTEREST_RATE << "\n";
    SavingsAccount::setAnnualInterestRate(MONTH_2_INTEREST_RATE);

    // Apply interest to savings accounts for first month
    cout << "Applying interest rate to accounts for second month\n";
    saver1.applyMonthlyInterest();
    saver2.applyMonthlyInterest();
    cout << "Savings account #1 balance:  "
        << saver1.getSavingsBalance() << "\n";
    cout << "Savings account #2 balance:  "
        << saver2.getSavingsBalance() << "\n";

    // Test illegal interest rates and balances
    cout << "Testing illegal interest rates and balances\n";
    SavingsAccount saver3(ILLEGAL_INITIAL_BALANCE);
    SavingsAccount::setAnnualInterestRate(ILLEGAL_INTEREST_RATE);
}
