/******************************************************************************
 * Homework #3 - CSE40477
 *
 * File:    SavingsAccount.h
 * Author:  Ray Mitchell
 *****************************************************************************/
#ifndef RAYMITCHELL_SAVINGSACCOUNT_H
#define RAYMITCHELL_SAVINGSACCOUNT_H

namespace RayMitchell
{
    class SavingsAccount
    {
    public:
        // Constructors
        SavingsAccount(double initialBalance);

        // Accessors / mutators
        double getSavingsBalance() const;

        // Apply monthly interest to current balance
        void applyMonthlyInterest();

        // Change the interest rate (applies to all SavingsAccounts)
        static void setAnnualInterestRate(double newInterestRate);

    private:
        // Current balance for this account
        double savingsBalance;

        // The interest rate (applies to all SavingsAccounts)
        static double annualInterestRate;
    };
}

#endif
