/*
* Vending Machine Project
* CSE-40477
*
* DeliveryChute.cpp
* YOU MUST IMPLEMENT THE FUNCTIONS IN THIS FILE.
*/
#include "DeliveryChute.h"

Project1::DeliveryChute::DeliveryChute(StatusPanel &statusPanel)
    : statusPanel(statusPanel),
      pProduct(0)
{
    // TODO: Implement
}

Project1::DeliveryChute::~DeliveryChute()
{
    // TODO: Implement
}

bool
Project1::DeliveryChute::insertProduct(Product *pProduct)
{
    // TODO: Implement
    return false;
}

Project1::Product *
Project1::DeliveryChute::retrieveProduct()
{
    // TODO: Implement
    return 0;
}

bool
Project1::DeliveryChute::containsProduct() const
{
    // TODO: Implement
    return false;
}